# Site de vendas: Kits de Natal

Páginas estáticas (HTML puro), prontas para o GitHub Pages.

- `index.html`: página inicial com os 3 kits
- `pagina-vendas-*.html`: uma página de venda por kit
- `pagamento-*.html`: uma página de pagamento por kit

## Antes de publicar
1. Em cada `pagamento-*.html`, edite o bloco `EDITE AQUI` e cole os links da sua plataforma de pagamento.
2. Troque `[Nome da sua marca ou empresa]` e `[seu e-mail ou WhatsApp]` no rodapé de todas as páginas.
3. Ajuste `FIM_PROMOCAO` (data final do preço de Natal) se precisar.
